============
Installation
============

At the command line::

    $ easy_install es_fluent

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv es_fluent
    $ pip install es_fluent
