# -*- coding: utf-8 -*-

__author__ = 'Jacob Straszynski'
__email__ = 'jacob.straszynski@planet.com'
__version__ = '0.1.0'
